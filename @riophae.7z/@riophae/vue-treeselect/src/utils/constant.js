export { default as constant } from 'lodash/constant'
