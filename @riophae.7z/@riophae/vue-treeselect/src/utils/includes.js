export function includes(arrOrStr, elem) {
  return arrOrStr.indexOf(elem) !== -1
}
