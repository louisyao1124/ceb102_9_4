export const createMap = () => Object.create(null)
