export { default as last } from 'lodash/last'
