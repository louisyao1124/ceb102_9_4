module.exports = {
  rules: {
    'import/no-default-export': 2,
    'import/prefer-default-export': 0,
  },
}
